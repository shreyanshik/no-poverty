// import React from 'react'

// setTimeout(() => {
//     window.location.href = "/";
//   }, 5000); 

// const PaymentPortal = () => {
//   return (
//     <div>PaymentPortal</div>
//   )
// }

// export default PaymentPortal